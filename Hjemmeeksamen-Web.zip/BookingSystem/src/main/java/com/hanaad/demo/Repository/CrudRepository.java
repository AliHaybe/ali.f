package com.hanaad.demo.Repository;

public interface CrudRepository<T, T1> {
}
