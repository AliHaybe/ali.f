package com.hanaad.demo.Repository;

import com.hanaad.demo.Model.Room;

public interface RoomRepository extends CrudRepository<Room, Long> {


}
